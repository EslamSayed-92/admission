<?php 

return [
	'admission'=>'Admission',
	'new'=>'New Application',
	'all'=>'All Applications',
	'upload'=>'Upload Apllications',

];