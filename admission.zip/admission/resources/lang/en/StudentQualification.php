<?php
return[
	'student_id' => 'Student',
	'qualification_id' => 'Qualification',
	'specialization_id' => 'Specialization',
	'grade' => 'Grade',
	'qualification_earn_date' => 'Qualification Earn Date',
	'school_id' => 'School',

	'title'=>'Students Qualifications',
	'new'=>'New',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
