<?php
return[
	'GPA' => 'GPA',
	'status_id' => 'Status',
	'absent_percentage' => 'Absent Percentage',
	'student_id' => 'Student',
	
	'title'=>'Student Followups',
	'new'=>'New Student Followup',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
