<?php
return[
	'school_name' => 'School Name',
	'title'=>'Schools',
	'new'=>'New School',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
