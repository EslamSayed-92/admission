<?php
return[
	'payment_receipt_id' => 'Payment Receipt',
	'payment_value' => 'Payment Value',
	'currency_id' => 'Currency',
	'payment_receipt_date'=>'Payment Receipt Date',
	'payment_type_id' => 'Payment Type',
	'title'=>'Payments',

	'student_admission_fees'=>'Student Admission Fees',
	'paid_message'=>'Student paid Admission Fees',
	'notpaid_message'=>"Student Haven't paid the admission fees yet",
	'academic_year_id'=>'Academic Year',
	'semester_id'=>'Semester',

	'new'=>'New Payment',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete',
];
