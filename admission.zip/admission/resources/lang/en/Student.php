<?php
return[
	'student_code'=>'Student Code',
	'student_admission_id' => 'Student Admission',
	'first_name' => 'First Name',
	'middle_name' => 'Middle Name',
	'last_name' => 'Last Name',
	'mobile_number' => 'Mobile Number',
	'admission_year_id' => 'Admission Year',
	'major_id' => 'Major',
	'faculty_id' => 'Faculty',

	'title'=>'Students',
	'new'=>'New Student',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
