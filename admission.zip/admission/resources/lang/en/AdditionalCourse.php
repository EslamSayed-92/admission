<?php
return[
	'additional_course_name' => 'Additional Course Name',
	'final_mark' => 'Final Mark',
	'pass_mark' => 'Pass Mark',

	'title'=>'Additional Courses',
	'new'=>'New Additional Course',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
