<?php
return[
	'specialization_name' => 'Specialization Name',
	'title'=>'Specializations',
	'new'=>'New Specialization',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete',
];
