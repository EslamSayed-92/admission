<?php

return [
	'document_check_list'=>'Document Check List',
	'student_military_data'=>'Student Military Data',
	'military_data_complete'=>'All Student Documents are complete, You will be directed to enter military data',
	'military_data_notcomplete'=>'Student Documents not complete, please complete documents first',
];