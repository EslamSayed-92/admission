<?php
return[
	'faculty_name' => 'Faculty Name',
	'university_id' => 'University',
	'faculty_logo' => 'Faculty Logo',
	'title'=>'Faculties',
	'new'=>'New Faculty',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
