<?php
return[
	'department_name' => 'Department Name',
	'faculty_id' => 'Faculty',

	'title'=>'Departments',
	'new'=>'New Department',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
