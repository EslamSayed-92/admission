<?php
return[
	'admission_status_description' => 'Admission Status Description',

	'title'=>'Admission Statuses',
	'new'=>'New Admission Status',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
