<?php 

return[
	'home'=>'Home',
	'new'=>'New Application',
	'all'=>'All Applications',
	'upload'=>'Uplaod Students Excel Sheet',
	'reports'=>'Admission Reports',
	'lang'=>'Language',
	'en'=>'en',
	'english'=>'English',
	'ar'=>'ar',
	'arabic'=>'Arabic',
	'login'=>'Login',
	'register'=>'Register',
];