<?php
return[
	'military_status_description' => 'Military Status Description',
	'title'=>'Military Statuses',
	'new'=>'New Military status',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
