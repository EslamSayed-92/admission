<?php
return[
	'academic_year_description' => 'Academic Year Description',
	'academic_year_start_date' => 'Academic Year Start Date',
	'academic_year_end_date' => 'Academic Year End Date',

	'title'=>'Academic Years',
	'new'=>'New Academic Year',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
