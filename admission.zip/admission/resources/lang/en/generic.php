<?php 

return[
	'direction'=>'ltr',
	'float'=>'left',
	'list'=>'List',
	'save'=>'Save',
	'select'=>'Select',
	'cancel'=>'Cancel',
	'edit'=>'Edit',
	'error'=>'Error !'
];