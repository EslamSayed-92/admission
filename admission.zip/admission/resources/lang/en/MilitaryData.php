<?php

return [
	'data'=>'',
	'number'=>'Military Number',
	'area'=>'Military Area',
	'delay'=>'Military Delay',
	'delay_date'=>'Military Delay Date',
	'delay_number'=>'Military Delay Number',
	'yes'=>'Yes',
	'no'=>'No',
	'available'=>'Is Military Delay Availble ?',

];