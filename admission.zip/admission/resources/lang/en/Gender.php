<?php
return[
	'gender_name' => 'Gender Name',
	'title'=>'Genders',
	'new'=>'New Gender',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
