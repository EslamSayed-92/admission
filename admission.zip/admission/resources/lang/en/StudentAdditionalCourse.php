<?php
return[
	'total_mark' => 'Total Mark',
	'exam_date' => 'Exam Date',
	'pass' => 'Pass',
	'student_id' => 'Student',
	'additional_course_id' => 'Additional Course',

	'title'=>'Student Additional Courses',
	'new'=>'New Student Additional Course',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
