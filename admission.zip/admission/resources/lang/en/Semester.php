<?php
return[
	'semester_name_english' => 'Semester Name English',
	'semester_name_arabic' => 'Semester Name Arabic',
	'title'=>'Semesters',
	'new'=>'New Semester',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
