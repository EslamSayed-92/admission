<?php
return[
	'document_name' => 'Document Name',
	'title'=>'Documents',
	'new'=>'New Document',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete',
];
