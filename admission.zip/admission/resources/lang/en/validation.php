<?php

return [
	'required'=>':field is required',
];