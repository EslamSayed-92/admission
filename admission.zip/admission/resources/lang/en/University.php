<?php
return[
	'university_name' => 'University Name',
	'university_logo' => 'University Logo',

	'title'=>'Universities',
	'new'=>'New Unversity',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
