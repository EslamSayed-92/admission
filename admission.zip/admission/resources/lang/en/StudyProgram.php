<?php
return[
	'study_program_description' => 'Study Program Description',
	'department_id' => 'Department',
	
	'title'=>'Study Programs',
	'new'=>'New Study Program',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
