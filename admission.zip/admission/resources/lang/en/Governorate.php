<?php
return[
	'governorate_name' => 'Governorate Name',
	'nationality_id' => 'Nationality',
	'title'=>'Governorates',
	'new'=>'New Governorate',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
