<?php
return[
	'currency_description' => 'Currency Description',

	'title'=>'Currency',
	'new'=>'New Currencies',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
