<?php
return[
	'nationality_name' => 'Nationality Name',
	'title'=>'Nationalities',
	'new'=>'New Nationality',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
