<?php
return[
	'military_area_name' => 'Military Area Name',
	'title'=>'Military Areas',
	'new'=>'New Military Area',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
