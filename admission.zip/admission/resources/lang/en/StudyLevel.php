<?php
return[
	'level_description' => 'Level Description',

	'title'=>'Levels',
	'new'=>'New Level',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
