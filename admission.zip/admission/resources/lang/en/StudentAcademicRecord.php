<?php
return[
	'academic_year_id' => 'Academic Year',
	'semester_id' => 'Semester',
	'number_of_registered_courses' => 'Number Of Registered Courses',
	'number_of_registered_credit_hours' => 'Number Of Registered Credit Hours',
	'number_of_withdrawed_courses' => 'Number Of Withdrawed Courses',
	'number_of_withdrawed_credit_hours' => 'Number Of Withdrawed Credit Hours',
	'semester_status' => 'Semester Status',
	'smester_GPA' => 'Smester GPA',
	'accumlated_GPA' => 'Accumlated GPA',
	'major_id' => 'Major',
	'specialization_id' => 'Specialization',
	'minor_id' => 'Minor',
	'student_major_sheet_id' => 'Student Major Sheet',
	'total_number_of_alerts' => 'Total Number Of Alerts',
	'faculty_id' => 'Faculty',
	'department_id' => 'Department',
	'student_exam_seat_number' => 'Student Exam Seat Number',
	'comments' => 'Comments',

	'title'=>'Student Academic Records',
	'new'=>'New Student Academic Record',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
