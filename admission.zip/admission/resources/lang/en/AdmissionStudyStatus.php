<?php
return[
	'admission_study_status_description' => 'Admission Study Status Description',
	
	'title'=>'Admission Study Statuses',
	'new'=>'New Admission Study Status',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
