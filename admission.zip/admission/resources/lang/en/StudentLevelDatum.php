<?php
return[
	'seat_number' => 'Seat Number',
	'level_GPA' => 'Level GPA',
	'specialization_id' => 'Specialization',
	'student_id' => 'Student',
	'study_level_id' => 'Study Level',
	'academic_year_id' => 'Academic Year',

	'title'=>'Students Levels',
	'new'=>'New Student Level',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
