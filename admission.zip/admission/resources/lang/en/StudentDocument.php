<?php
return[
	'student_admission_id' => 'Student Admission',
	'document_id' => 'Document',
	'document_picture' => 'Document Picture',
	
	'title'=>'Student Documents',
	'new'=>'New Student Document',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
