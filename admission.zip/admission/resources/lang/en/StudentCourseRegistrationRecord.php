<?php
return[
	'classwork' => 'Classwork',
	'final_exam_mark' => 'Final Exam Mark',
	'Grade' => 'Grade',
	'student_id' => 'Student',
	'course_id' => 'Course',
	'semester_id' => 'Semester',
	'academic_year_id' => 'Academic Year',
	'group_number' => 'Group Number',

	'title'=>'Student Course Registartion Records',
	'new'=>'New Student Course Registartion Record',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete',
];
