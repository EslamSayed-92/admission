<?php
return[
	'religion_name' => 'Religion Name',
	'title'=>'Religions',
	'new'=>'New Religion',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
