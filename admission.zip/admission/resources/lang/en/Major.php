<?php
return[
	'major_name' => 'Major Name',
	'title'=>'Majors',
	'new'=>'New Major',
	'set'=>'Set Student Academic Data',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete'
];
