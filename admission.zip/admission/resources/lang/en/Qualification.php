<?php
return[
	'qualification_name' => 'Qualification Name',
	'title'=>'Qualifications',
	'new'=>'New Qualification',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete',
];
