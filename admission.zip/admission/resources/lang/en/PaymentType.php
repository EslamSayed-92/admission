<?php
return[
	'payment_type_name' => 'Payment Type Name',
	'payment_value' => 'Payment Value',
	'title'=>'Payment Types',
	'new'=>'New Payment Type',
	'show'=>'Show',
	'edit'=>'Edit',
	'delete'=>'Delete',
];
