<?php
return[
	'payment_type_name' => 'نوع المدفوعات',
	'payment_value' => 'القيمة المدفوعة',

	'title'=>'أنواع المدفوعات',
	'new'=>'نوع مدفوعات جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
