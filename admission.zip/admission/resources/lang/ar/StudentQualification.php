<?php
return[
	'student_id' => 'الطالب',
	'qualification_id' => 'المؤهل',
	'specialization_id' => 'التخصص',
	'grade' => 'التقدير / الدرجة',
	'qualification_earn_date' => 'تاريخ الحصول عليها',
	'school_id' => 'المدرسة',

	'title'=>'مؤهلات الطلاب',
	'new'=>'مؤهل جديد لطالب',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
