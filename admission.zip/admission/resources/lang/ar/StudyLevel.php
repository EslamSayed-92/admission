<?php
return[
	'level_description' => 'المستوي الدراسي',

	'title'=>'المستويات الدراسية',
	'new'=>'مسنوي دراسي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];