<?php
return[
	'university_name' => 'الجامعة',
	'university_logo' => 'رمز الجامعة',

	'title'=>'الجامعات',
	'new'=>'جامعة جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
