<?php
return[
	'religion_name' => 'الديانة',

	'title'=>'الأديان',
	'new'=>'ديانة جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

