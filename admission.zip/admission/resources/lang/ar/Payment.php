<?php
return[
	'payment_receipt_id' => 'رقم الإيصال',
	'payment_value' => 'القيمة المدفوعة',
	'currency_id' => 'العملة',
	'payment_receipt_date'=>'تاريخ الإيصال',
	'payment_type_id' => 'نوع المدفوعات',

	'student_admission_fees'=>'مصاريف تقديم الطالب',
	'paid_message'=>'قام الطالب بدفع مصاريف التقديم',
	'notpaid_message'=>"لم يدفع الطالب مصاريف التقديم بعد",
	'academic_year_id'=>'العام دراسي',
	'semester_id'=>'الفصل الدراسي',

	'title'=>'المدفوعات',
	'new'=>'مدفوعات جديدة',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
