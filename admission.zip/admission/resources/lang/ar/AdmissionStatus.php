<?php
return[
	'admission_status_description' => 'حالة القبول',
	'title'=>'حالات القبول',
	'new'=>'حالة قبول جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

