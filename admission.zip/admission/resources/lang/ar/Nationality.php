<?php
return[
	'nationality_name' => 'الجنسية',

	'title'=>'الجنسيات',
	'new'=>'جنسية جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
