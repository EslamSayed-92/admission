<?php
return[
	'school_name' => 'المدرسة',

	'title'=>'المدارس',
	'new'=>'مدرسة جديدة',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
