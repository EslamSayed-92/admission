<?php
return[
	'document_name' => 'إسم المستند',

	'title'=>'المستندات',
	'new'=>'مستند جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

