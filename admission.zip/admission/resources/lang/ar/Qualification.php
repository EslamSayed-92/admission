<?php
return[
	'qualification_name' => 'المؤهل',

	'title'=>'المؤهلات',
	'new'=>'مؤهل جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
