<?php
return[
	'classwork' => 'أعمال السنة',
	'final_exam_mark' => 'درجة تاإمتحان النهائي',
	'Grade' => 'التقدير',
	'student_id' => 'الطالب',
	'course_id' => 'المادة',
	'semester_id' => 'الفصل الدراسي',
	'academic_year_id' => 'العام الدراسي',
	'group_number' => 'رقم المجموعة',

	'title'=>'سجلات تسجيل الطلاب الدراسية',
	'new'=>'سجل تسجيل الطالب الدراسي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
