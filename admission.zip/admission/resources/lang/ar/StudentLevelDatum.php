<?php
return[
	'seat_number' => 'رقم الجلوس',
	'level_GPA' => 'المعدل التراكمي للمستوي الدراسي',
	'specialization_id' => 'التخصص',
	'student_id' => 'الطالب',
	'study_level_id' => 'المستوي الدراسي',
	'academic_year_id' => 'العام الدراسي',

	'title'=>'المستويات الدراسية للطالب',
	'new'=>'مستوي دراسي جديد لطالب',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
