<?php
return[
	'student_admission_id' => 'رقم تقديم الطالب',
	'document_id' => 'المستند',
	'document_picture' => 'صورة المستند',

	'title'=>'مستندات الطلاب',
	'new'=>'مستند جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
