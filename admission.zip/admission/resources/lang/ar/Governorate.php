<?php
return[
	'governorate_name' => 'المحافظة',
	'nationality_id' => 'الجنسية',

	'title'=>'الجنسيات',
	'new'=>'جنسية جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];

