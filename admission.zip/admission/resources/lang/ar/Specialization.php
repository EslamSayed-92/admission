<?php
return[
	'specialization_name' => 'إسم التخصص',
	'title'=>'التخصصات',
	'new'=>'تخصص جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
