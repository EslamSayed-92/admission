<?php
return[
	'faculty_name' => 'الكلية',
	'university_id' => 'الجامعة',
	'faculty_logo' => 'رمز الكلية',

	'title'=>'الكليات',
	'new'=>'كلية جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

