<?php
return[
	'military_area_name' => 'المنطقة العسكرية',

	'title'=>'المناطق العسكرية',
	'new'=>'منطقة عسكرية جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];

