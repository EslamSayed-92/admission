<?php
return[
	'gender_name' => 'النوع',

	'title'=>'الأنواع',
	'new'=>'نوع جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];

