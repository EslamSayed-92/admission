<?php
return[
	'department_name' => 'القسم',
	'faculty_id' => 'الكلية',

	'title'=>'الأقسام',
	'new'=>'قسم جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

