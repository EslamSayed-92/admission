<?php
return[
	'military_status_description' => 'حالة التجنيد',

	'title'=>'حالات التجنيد',
	'new'=>'حالة تجنيد جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
