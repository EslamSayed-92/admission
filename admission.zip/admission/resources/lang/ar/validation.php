<?php

return [
	'required'=>':field يجب',
];