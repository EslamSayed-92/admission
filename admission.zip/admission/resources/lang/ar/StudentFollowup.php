<?php
return[
	'GPA' => 'المعد التراكمي',
	'status_id' => 'حالة التسجيل',
	'absent_percentage' => 'نسبة الغياب',
	'student_id' => 'الطالب',

	'title'=>'متابعات الطلاب',
	'new'=>'متابعة جديدة لطالب',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
