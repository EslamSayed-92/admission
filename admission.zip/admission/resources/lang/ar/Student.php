<?php
return[
	'student_code'=>'كود الطالب',
	'student_admission_id' => 'رقم قبول الطالب',
	'first_name' => 'الإسم الأول',
	'middle_name' => 'الإسم الثاني',
	'last_name' => 'الإسم الأخير',
	'mobile_number' => 'رقم الموبايل',
	'admission_year_id' => 'عام الإلتحاق',
	'major_id' => 'التخصص الرئيسي',
	'faculty_id' => 'الكلية',

	'title'=>'الطلاب',
	'new'=>'طالب جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف',
];
