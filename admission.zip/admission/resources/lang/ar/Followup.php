<?php

return [
	'document_check_list'=>'قائمة مستندات التقديم',
	'student_military_data'=>'بيانات تجدنيد الطالب',
	'military_data_complete'=>'جميع مستندات الطالب مكتملة, سوف يتم تحويلك لإدخال بيانات تجنيد الطالب',
	'military_data_notcomplete'=>'مستندات الطالب غير مكتملة, من فضلك أكمل مستندات الطالب أولا',
];