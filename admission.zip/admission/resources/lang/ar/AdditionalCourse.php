<?php
return[
	'additional_course_name' => 'إسم المادة الإضافية',
	'final_mark' => 'الدرجة النهائية',
	'pass_mark' => 'درجة النجاح',

	'title'=>'المقررات الإضافية',
	'new'=>'مقرر إضافي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

