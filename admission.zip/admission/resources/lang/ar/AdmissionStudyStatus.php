<?php
return[
	'admission_study_status_description' => 'حالة التسجيل',
	'title'=>'حالات التسجيل',
	'new'=>'حالة تسجيل جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

