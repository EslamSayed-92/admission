<?php
return[
	'study_program_description' => 'برنامج الدراسة',
	'department_id' => 'القسم',

	'title'=>'البرامج الدراسية',
	'new'=>'برنامج دراسي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
