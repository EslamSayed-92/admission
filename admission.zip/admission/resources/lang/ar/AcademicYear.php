<?php
return[
	'academic_year_description' => 'إسم العام الدراسي',
	'academic_year_start_date' => 'تاريخ بداية العام الدراسي',
	'academic_year_end_date' => 'تاريخ نهاية العام الدراسي',

	'title'=>'الأعوام الدراسية',
	'new'=>'عام دراسي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

