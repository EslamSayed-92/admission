<?php
return[
	'semester_name_english' => 'إسم الفصل الدراسي بالإنجليزية',
	'semester_name_arabic' => 'إسم الفصل الدراسي بالعربية',

	'title'=>'الفصو الدراسية',
	'new'=>'فصل دراسي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
