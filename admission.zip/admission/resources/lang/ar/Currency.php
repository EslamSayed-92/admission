<?php
return[
	'currency_description' => 'إسم العملة',
	'title'=>'العملات',
	'new'=>'عملة جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];

