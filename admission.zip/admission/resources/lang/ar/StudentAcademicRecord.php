<?php
return[
	'academic_year_id' => 'العام الدراسي',
	'semester_id' => 'الفصل الدراسي',
	'number_of_registered_courses' => 'عدد المواد المسجلة',
	'number_of_registered_credit_hours' => 'عدد الساعات المعتمدة المسجلة',
	'number_of_withdrawed_courses' => 'عدد المواد المردودة',
	'number_of_withdrawed_credit_hours' => 'عدد الساعات المعتمدة المردودة',
	'semester_status' => 'حالة التسجيل للفصل الدراسي',
	'smester_GPA' => 'المعدل التراكمي للفصل الدراسي',
	'accumlated_GPA' => 'المعدل التراكمي ',
	'major_id' => 'التخصص الرئيسي',
	'specialization_id' => 'التخصص',
	'minor_id' => 'التخصص الثانوي',
	'student_major_sheet_id' => '',
	'total_number_of_alerts' => 'إجمالي عدد الإنذارات',
	'faculty_id' => 'الكلية',
	'department_id' => 'القسم',
	'student_exam_seat_number' => 'رقم جلوس الإمتحانات',
	'comments' => 'تعليقات',

	'title'=>'السجلات الأكاديمية',
	'new'=>'سجل أكاديمي جديد',
	'show'=>'عرض',
	'edit'=>'تعديل',
	'delete'=>'حذف'
];
