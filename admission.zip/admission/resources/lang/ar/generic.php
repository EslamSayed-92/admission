<?php 

return[
	'direction'=>'rtl',
	'float'=>'right',
	'list'=>'قائمة',
	'save'=>'حفظ',
	'select'=>'إختر',
	'cancel'=>'إلغاء',
	'edit'=>'تعديل',
	'error'=>'خطأ !'
];