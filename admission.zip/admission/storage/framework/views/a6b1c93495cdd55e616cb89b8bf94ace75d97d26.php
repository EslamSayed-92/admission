<?php $__env->startSection('title'); ?>
    <?php echo e(trans( trim($create_url,'/').".title" )); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container mt-5">

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="row">
			<div class="col-sm-5 font-weight-bold">
			<?php echo e(trans( trim($create_url,'/').".".$key )); ?> :
			</div>
			<div class="col-sm-7"><?php echo e($val); ?></div>
		</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="row">
			<div class="col-sm-2"></div>
			<div class="col-sm-7 text-center">
				<a class="btn btn-primary" href="<?php echo e($create_url); ?>/<?php echo e(reset($data)); ?>/edit">
				<?php echo e(trans( trim($create_url,'/').".edit" )); ?></a>
				<a class="btn btn-danger" data-method="delete" data-token="<?php echo csrf_token();?>"
				 href="<?php echo e($create_url); ?>/<?php echo e(reset($data)); ?>" data-confirm="Are you sure you want to delete this item ?"><?php echo e(trans( trim($create_url,'/').".delete" )); ?></a>
				<a class="btn btn-success" href="<?php echo e($create_url); ?>"><?php echo e(trans("generic.list" )); ?> <?php echo e(trans( trim($create_url,'/').".title" )); ?></a>
			</div>
			<div class="col-sm-2"></div>
			
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>