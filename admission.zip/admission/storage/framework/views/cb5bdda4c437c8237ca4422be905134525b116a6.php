<?php $__env->startSection('title'); ?>
    <?php echo e(__('welcome.admission')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container full-height flex-center">
        <h1 class="title m-b-md">
            <?php echo e(__('welcome.admission')); ?>

        </h1>

        <div class="links">
            <a href="/StudentAdmission/create"><?php echo e(__('welcome.new')); ?></a>
            <a href="/StudentAdmission"><?php echo e(__('welcome.all')); ?></a>
            <a href="/excel"><?php echo e(__('welcome.upload')); ?></a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>