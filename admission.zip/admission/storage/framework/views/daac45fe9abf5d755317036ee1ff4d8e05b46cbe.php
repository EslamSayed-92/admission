<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container flex-center">
	<h1 class="font-weight-bold text-primary"><?php echo e($header); ?></h1>

	<div class="row">
		<div class="col-sm-3 rounded border border-dark shadow p-3 mb-5 bg-white rounded flex-center">
			<h3 class="font-weight-bold text-info" >Military Reports</h3>
			<ul class="flex-center">
				<li><a href="<?php echo e(url()->current()); ?>/MilitaryDelays">Military Delays</a></li>
			</ul>
		</div>
		<div class="col-sm-3 rounded border border-dark shadow p-3 mb-5 bg-white rounded flex-center ml-3">
			<h3 class="font-weight-bold text-info">Admission Reports</h3>
		</div>
		<div class="col-sm-3 rounded border border-dark shadow p-3 mb-5 bg-white rounded flex-center ml-3">
			<h3 class="font-weight-bold text-info">Other Reports</h3>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>