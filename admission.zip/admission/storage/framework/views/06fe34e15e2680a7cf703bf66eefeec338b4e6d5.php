<div class="page-header">
  <nav class="navbar navbar-expand-lg navbar-dark flex-column flex-md-row bd-navbar">
      <a href="#" data-target="#sidebar" data-toggle="collapse"><i class="fa fa-navicon fa-2x py-2 p-1"></i></a>

      <!-- Links  -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- Brand  -->
          <a class="nav-link" href="/"><?php echo e(trans('navbar.home')); ?></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/StudentAdmission/create"><?php echo e(trans('navbar.new')); ?></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/StudentAdmission"><?php echo e(trans('navbar.all')); ?></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/excel"><?php echo e(trans('navbar.upload')); ?></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/AdmissionReports"><?php echo e(trans('navbar.reports')); ?></a>
        </li>

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo e(trans('navbar.lang')); ?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item change-lang" value="<?php echo e(trans('navbar.en')); ?>"><?php echo e(trans('navbar.english')); ?></a>
          <a class="dropdown-item change-lang" value="<?php echo e(trans('navbar.ar')); ?>"><?php echo e(trans('navbar.arabic')); ?></a>
        </div>
      </li>

        <?php if(Route::has('login')): ?>
        <li class="nav-item">
            <div class="top-right links">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/home')); ?>"><?php echo e(trans('navbar.home')); ?></a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"><?php echo e(trans('navbar.login')); ?></a>
                    <a href="<?php echo e(route('register')); ?>"><?php echo e(trans('navbar.register')); ?></a>
                <?php endif; ?>
            </div>
        </li>
        <?php endif; ?>
      </ul>
  </nav>
</div>

