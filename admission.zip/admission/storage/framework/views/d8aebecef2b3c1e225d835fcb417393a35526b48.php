<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href=" https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.min.css">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/collapsable.css')); ?>">
        <style type="text/css">
          li.nav-item{border-<?php echo e(trans('generic.float')); ?>: solid 1px rgba(255,255,255,.5);}
        </style>
    </head>
<body>
  <div class="container-fluid">
    <div class="row d-flex d-md-block flex-nowrap wrapper">
        <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <main class="col-md-9 float-<?php echo e(trans('generic.float')); ?> col main" dir="<?php echo e(trans('generic.direction')); ?>">
            <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row px-2 pl-1 pt-2">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <div class="row">
              <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </main>

    </div>
  </div>

  <?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <script type="text/javascript">
      function activate_datepicker()
      {
        $( ".datepicker" ).datepicker({
          format: 'dd-mm-yyyy',
          changeMonth: true,
          changeYear: true
        });
        $('.datepicker').on('dp.change', function(event) {
          event.date.format('dd-mm-yyyy')
        });

      }

      $(function() {activate_datepicker();});
      window.locale = "<?php echo App::getLocale();; ?>";

    </script>

</body>
</html>