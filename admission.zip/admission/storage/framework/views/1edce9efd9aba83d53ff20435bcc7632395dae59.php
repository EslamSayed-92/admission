<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<h1 class="title m-b-md">
           <?php echo e($title); ?>

    </h1>
	<?php echo Form::open(['url' => $update_url, 'method' => 'put']); ?>


	<?php echo Form::token(); ?>


	<div class='form-group row center-block'>
      <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class='form-group row'>
		<?php echo Form::Label( 'military_number', 'Military Number', ['class'=>'col-sm-3 col-form-label']); ?>

	    <div class='col-sm-9'>
	    	<?php echo Form::number('military_number',$student_military_data['military_number'] ,['class'=>'form-control']);; ?>

	    </div>
    </div>

    <div class='form-group row'>
	    <?php echo Form::Label('military_area_id', 'Military Area', ['class'=>'col-sm-3 col-form-label']); ?>

	    <div class='col-sm-9'>
	    <?php echo Form::select('military_area_id',$military_areas,$student_military_data['military_area_id'] ,['placeholder' => 'select...','class'=>'form-control']);; ?>

	    </div>
    </div>

    <div class='form-group row'>
	    <?php echo Form::Label('military_delay', 'Is Military Delay Availble ?', ['class'=>'col-sm-3 col-form-label']); ?>

	    <div class='col-sm-9'>
	    	<div class="form-check form-check-inline">
	    		<?php if($student_military_data['military_delay']=='yes'): ?>
	    		<input class="form-check-input military-delay" type="radio" name="military_delay" checked disabled="disabled" value="yes">
	    		<?php else: ?>
	    		<input class="form-check-input military-delay" type="radio" name="military_delay" value="yes">
	    		<?php endif; ?>
	    		<?php echo Form::Label('military_delay', 'Yes', ['class'=>'form-check-label']); ?>

			</div>
			<div class="form-check form-check-inline">
			 	<?php if($student_military_data['military_delay']=='no'): ?>
	    		<input class="form-check-input military-delay" type="radio" name="military_delay" checked disabled="disabled" value="no">
	    		<?php else: ?>
	    		<input class="form-check-input military-delay" type="radio" name="military_delay" value="no">
	    		<?php endif; ?>
	    		<?php echo Form::Label('military_delay', 'No', ['class'=>'form-check-label']); ?>

			</div>
	    </div>
    </div>

    <?php if($student_military_data['military_delay']=='yes'): ?>
    	<div class='form-group row'>
			<?php echo Form::Label('military_delay_number', 'Military Delay Number', ['class'=>'col-sm-3 col-form-label']); ?>

			<div class='col-sm-9'>
			<?php echo Form::number('military_delay_number',$student_military_data['military_delay_number'] ,['class'=>'form-control','autocomplete'=>'off']);; ?>	
			</div>
		</div>
		<div class='form-group row'>
			<?php echo Form::Label('military_delay_date', 'Military Delay Date', ['class'=>'col-sm-3 col-form-label']); ?>

			<div class='col-sm-9'>
				<?php echo Form::text('military_delay_date',
				date_format(date_create($student_military_data['military_delay_date']),'d-m-Y') ,
				['class'=>'form-control datepicker','autocomplete'=>'off']);; ?>

			</div>
		</div>
    <?php endif; ?>

	<div class='form-group row center-block'>
		<div class='col-md-4'></div>
		<div class='col-md-7'>
			<?php echo Form::submit('Save',['class'=>'btn btn-primary col-md-4 center-block']); ?>

			<input type='button' class='btn btn-secondary col-md-2 center-block' value='Cancel' onclick='window.history.back()'>
		</div>
	</div>
<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>