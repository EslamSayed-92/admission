<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
        <h1 class="title m-b-md">
            <?php echo e($title); ?>

        </h1>
		
		<?php echo Form::open(['url' => "$create_url", 'method' => 'post']); ?>


		<?php echo Form::token(); ?>


		<div class="form-group row center-block" >
	      <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    </div>

		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		    <?php if($val === 'string'): ?>
		    	<div class="form-group row">
		    		<?php echo Form::Label($key, ucwords(str_replace("_", " ", $key)), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::text($key,'',['class'=>'form-control','autocomplete'=>'off']);; ?>

				    </div>
			    </div>

			<?php elseif( $val == 'date'): ?>
				<div class="form-group row">
		    		<?php echo Form::Label($key, ucwords(str_replace("_", " ", $key)),['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::text($key, '', ['class' => 'datepicker form-control','autocomplete'=>'off']);; ?>

				    </div>
				</div>
		    

		    <?php elseif( $val == 'int' || $val == 'float' || $val == 'double'): ?> 
		    	<div class="form-group row">
				    <?php echo Form::Label($key, ucwords(str_replace("_", " ", $key)), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::number($key,'',['class'=>'form-control','step'=>'any','autocomplete'=>'off']);; ?>

				    </div>
			    </div>

			<?php elseif(is_array($val)): ?>
				<div class="form-group row">
				    <?php echo Form::Label($key, ucwords(str_replace("_", " ", str_replace("_id","",$key))), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    <?php echo Form::select($key,$val, null,['placeholder' => 'select...','class'=>'form-control']);; ?>

				    </div>
			    </div>

		    <?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
		<div class="form-group row center-block">
			<div class="col-md-4"></div>
			<div class="col-md-7">
				<?php echo Form::submit('Save',['class'=>'btn btn-primary col-md-4 center-block']); ?>

				<a class="btn btn-secondary ml-2 float-sm-right" href="<?php echo e($create_url); ?>">Cancel</a>
			</div>
		</div>
		<?php echo Form::close(); ?>

		
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>