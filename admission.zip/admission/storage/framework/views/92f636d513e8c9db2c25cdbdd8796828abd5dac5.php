<?php $__env->startSection('title'); ?>
    <?php echo e(trans( "$model.title" )); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
        <h1 class="title m-b-md">
            <?php echo e(trans( "$model.new" )); ?>

        </h1>

		<?php echo Form::open(['url' => "$create_url", 'method' => 'post']); ?>


		<?php echo Form::token(); ?>


		<div class="form-group row center-block" >
	      <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    </div>

		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		    <?php if($val === 'string'): ?>
		    	<div class="form-group row">
		    		<?php echo Form::Label($key, trans( "$model.$key" ), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::text($key,'',['class'=>'form-control','autocomplete'=>'off']);; ?>

				    </div>
			    </div>

			<?php elseif( $val == 'date'): ?>
				<div class="form-group row">
		    		<?php echo Form::Label($key, trans( "$model.$key" ),['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::text($key, '', ['class' => 'datepicker form-control','autocomplete'=>'off']);; ?>

				    </div>
				</div>
		    

		    <?php elseif( $val == 'int' || $val == 'float' || $val == 'double'): ?> 
		    	<div class="form-group row">
				    <?php echo Form::Label($key, trans( "$model.$key" ), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::number($key,'',['class'=>'form-control','step'=>'any','autocomplete'=>'off']);; ?>

				    </div>
			    </div>

			<?php elseif(is_array($val)): ?>
				<div class="form-group row">
				    <?php echo Form::Label($key, trans( "$model.$key" ), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    <?php echo Form::select($key,$val, null,['placeholder' => 'select...','class'=>'form-control']);; ?>

				    </div>
			    </div>

		    <?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
		<div class="form-group row center-block">
			<div class="col-md-4"></div>
			<div class="col-md-7">
				<?php echo Form::submit( trans("generic.save"),['class'=>'btn btn-primary col-md-4 center-block']); ?>


				<a class="btn btn-secondary ml-2" href="<?php echo e($back); ?>"><?php echo e(trans("generic.cancel")); ?></a>
			</div>
		</div>
		<?php echo Form::close(); ?>

		
		

		<!-- Modal -->
		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel"></h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		          <input type="hidden" value="<?php echo csrf_token();?>" name="_token">
		        </button>
		      </div>	
		      <div class="modal-body">
		        
		      </div>

		    </div>
		  </div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>