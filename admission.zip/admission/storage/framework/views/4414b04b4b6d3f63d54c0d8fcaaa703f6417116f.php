<?php $__env->startSection('title'); ?>
    <?php echo e(trans( trim($create_url,'/').".title" )); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
        <h1 class="title m-b-md">
            <?php echo e(trans( trim($create_url,'/').".title" )); ?>

        </h1>
        <div class="row mx-auto">
        	<a class="btn btn-primary" href="<?php echo e($create_url); ?>/create"><?php echo e(trans( trim($create_url,'/').".new" )); ?></a>
        </div>
		<table class="table table-bordered table-hover">
			<tr>
				<th scope="col">#</th>

				<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <th scope="col"><?php echo e(trans( trim($create_url,'/').".".$header )); ?></th>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tr>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr scope="row">
				<td><?php echo e($loop->iteration); ?></td>
				<?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($loop->iteration>1): ?>
					<td><?php echo e($item); ?></td>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<td><a class="btn btn-success" href="<?php echo e($create_url); ?>/<?php echo e(reset($row)); ?>"><?php echo e(trans( trim($create_url,'/').".show" )); ?></a></td>
				<td><a class="btn btn-primary" href="<?php echo e($create_url); ?>/<?php echo e(reset($row)); ?>/edit"><?php echo e(trans( trim($create_url,'/').".edit" )); ?></a></td>
				<td>
					<a class="btn btn-danger" data-method="delete" data-token="<?php echo csrf_token();?>" href="<?php echo e($create_url); ?>/<?php echo e(reset($row)); ?>" data-confirm="Are you sure you want to delete this item ?"><?php echo e(trans( trim($create_url,'/').".delete" )); ?></a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</table>
		
		
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>