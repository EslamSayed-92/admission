<?php $__env->startSection('title'); ?>
    Mapper
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row" style="margin-top: 1%">
		<h3>Drag the headers from excel sheet to corresponding fields in database</h3>
		<br/>

		<?php echo Form::open(['url' => "$upload_url", 'method' => 'post', 'class' => 'col-sm-5']); ?>

		<h3><u>Database Fields</u></h3>

		<?php echo Form::token(); ?>

			<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="form-group">
				<?php echo Form::Label($key, ucwords(str_replace("_", " ", $key)), ['class'=>'col-sm-5 col-form-label']); ?>


				<?php echo Form::text($key,'',['class'=>'form-control col-sm-6', 'style'=>'display:inline',
				'ondrop'=>'drop(event)', 'ondragover'=>'allowDrop(event)']);; ?>

				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<div class="form-group row center-block">
				<div class="col-md-4"></div>
				<div class="col-md-7">
					<?php echo Form::submit('Submit',['class'=>'btn btn-primary col-md-4 center-block']); ?>

					<input type="button" class="btn btn-secondary col-md-4 center-block" value="Cancel" onclick="window.history.back()">
				</div>
			</div>

		<?php echo Form::close(); ?>


		<div class="col-sm-5" id="headers">
			<h3><u>Excel Sheet Headers</u></h3>
			<table class="table table-bordered table-hover">
			<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr ondrop="drop(event)" ondragover="allowDrop(event)">
					<th scope="col" draggable="true" ondragstart="drag(event)"><?php echo e($header); ?></th>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>

	<script>
		window.onscroll = function() {StickyHeaders()};

		// Get the header
		var headers = document.getElementById("headers");

		// Get the offset position of the navbar
		var sticky = headers.offsetTop;

		// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
		function StickyHeaders() {
		  if (window.pageYOffset > sticky) {
		    headers.classList.add("sticky");
		  } else {
		    headers.classList.remove("sticky");
		  }
		}


		var data;
		var td;
		function allowDrop(ev) {
		    ev.preventDefault();
		}

		function drag(ev) {
			data = ev.target.textContent;
			td = ev.target;
		}

		function drop(ev) {
		    ev.preventDefault();
		    ev.target.value = data;
		    td.classList.add("alert-success")
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>