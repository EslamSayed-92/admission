<?php $__env->startSection('title'); ?>
    <?php echo e(trans( "$model.title" )); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
        <h1 class="title m-b-md">
            <?php echo e(trans( "$model.edit" )); ?>

        </h1>
		
		<?php echo Form::open(['url' => "$edit_url", 'method' => 'put']); ?>


		<?php echo Form::token(); ?>


		<div class="form-group row center-block">
	      <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    </div>

		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		    <?php if($val['type'] === 'string'): ?>
		    	<div class="form-group row">
		    		<?php echo Form::Label($key, trans( "$model.$key" ), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::text($key,$val['value'],['class'=>'form-control','autocomplete'=>'off']);; ?>

				    </div>
			    </div>

			<?php elseif( $val['type'] == 'date'): ?>
				<div class="form-group row">
		    		<?php echo Form::Label($key, trans( "$model.$key" ),['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::text($key, $val['value'], ['class' => 'datepicker form-control','autocomplete'=>'off']);; ?>

				    </div>
				</div>
		    

		    <?php elseif( $val['type'] == 'int' || $val['type'] == 'float' || $val['type'] == 'double'): ?> 
		    	<div class="form-group row">
				    <?php echo Form::Label($key, trans( trim($model,'/').".".$key ), ['class'=>'col-sm-3 col-form-label', 'step'=>'any' ]); ?>

				    <div class="col-sm-9">
				    	<?php echo Form::number($key,$val['value'],['class'=>'form-control','autocomplete'=>'off']);; ?>

				    </div>
			    </div>

			<?php elseif(is_array($val['type'])): ?>
				<div class="form-group row">
				    <?php echo Form::Label($key, trans( "$model.$key" ), ['class'=>'col-sm-3 col-form-label']); ?>

				    <div class="col-sm-9">
				    <?php echo Form::select($key,$val['type'], $val['value'],['placeholder' => 'select...','class'=>'form-control']);; ?>

				    </div>
			    </div>

		    <?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
		<div class="form-group row center-block">
			<div class="col-md-4"></div>
			<div class="col-md-7">
				<?php echo Form::submit(trans("generic.save"),['class'=>'btn btn-primary col-md-4 center-block']); ?>


				<a class="btn btn-secondary ml-2" href="<?php echo e($back); ?>"><?php echo e(trans("generic.cancel")); ?></a>
			</div>
		</div>

		<?php echo Form::close(); ?>

		
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>