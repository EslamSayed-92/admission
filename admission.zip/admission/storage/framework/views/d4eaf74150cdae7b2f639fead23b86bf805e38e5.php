<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
        <h1 class="title m-b-md">
            <?php echo e($title); ?>

        </h1>

        <table class="table table-bordered">
	        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<th><?php echo e($val['name']); ?></th>
				<th>
					<?php if($val['submitted']): ?>
						<input type="checkbox" checked="true" name="<?php echo e($val['name']); ?>">
					<?php else: ?>
						<input type="checkbox" name="<?php echo e($val['name']); ?>">
					<?php endif; ?>
				</th>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>