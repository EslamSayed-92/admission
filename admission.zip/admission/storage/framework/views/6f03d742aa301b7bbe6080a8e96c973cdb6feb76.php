<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1 class="title m-b-md">
           <?php echo e($title); ?>

    </h1>
	<?php echo Form::open(['url' => $add_url, 'method' => 'post']); ?>


	<?php echo Form::token(); ?>


	<div class='form-group row center-block'>
      <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class='form-group row'>
		<?php echo Form::Label( 'military_number', 'Military Number', ['class'=>'col-sm-3 col-form-label']); ?>

	    <div class='col-sm-9'>
	    	<?php echo Form::number('military_number','',['class'=>'form-control']);; ?>

	    </div>
    </div>

    <div class='form-group row'>
	    <?php echo Form::Label('military_area_id', 'Military Area', ['class'=>'col-sm-3 col-form-label']); ?>

	    <div class='col-sm-9'>
	    <?php echo Form::select('military_area_id',$data, null,['placeholder' => 'select...','class'=>'form-control']);; ?>

	    </div>
    </div>

	<div class='form-group row center-block'>
		<div class='col-md-4'></div>
		<div class='col-md-7'>
			<?php echo Form::submit('Save',['class'=>'btn btn-primary col-md-4 center-block']); ?>

			<input type='button' class='btn btn-secondary col-md-2 center-block' value='Cancel' onclick='window.history.back()'>
		</div>
	</div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>